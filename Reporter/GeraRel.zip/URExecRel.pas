unit URExecRel;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  UTRELSIMPLES, Qrctrls, QuickRpt, ExtCtrls;

type
  TFRExecRel = class(TFTRelSimples)
    QRBDetail: TQRBand;
    QRCabec: TQRChildBand;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
    Procedure PreparaCampos;
  end;

var
  FRExecRel: TFRExecRel;

implementation

uses URelatorio_cl;

{$R *.DFM}

{ TFRExecRel }

procedure TFRExecRel.PreparaCampos;
Var wCont : Integer;
begin
  With DMRelatorio do
  Begin
    QRLTitulo.Caption := QRelatorioDesc_Titulo.Value;
    QRLNomeRel.Caption := QRelatorioNome_Relatorio.Value;
    QSelect.Open;
    For wCont := 0 to QExecRel.Fields.Count -1 do
    Begin
      // Criar cabe�alho
      With TQRLabel.Create(FRExecRel) do
      Begin
        Parent := QRCabec;
        QSelect.Locate('NOME_CAMPO', QExecRel.Fields[wCont].FieldName, []);
        Caption := QSelectNome_Alias.Value;
        Left := QSelectNum_Pos_X.Value;
        Top := QSelectNum_Pos_Y.Value;
        If QRCabec.Height < (Top + Height) Then
          QRCabec.Height := (Top + Height);
      End;

      // Criar campo do Relatorio
      With TQRDBText.Create(FRExecRel) do
      Begin
        Parent := QRBDetail;
        ParentReport := QRPrimario;
        DataSet := DMRelatorio.QExecRel;
        DataField := QExecRel.Fields[wCont].FieldName;
        If QSelectDesc_Tipo_Dado.Value = 'NUMBER' Then
          Alignment := taRightJustify;
        Left := QSelectNum_Pos_X.Value;
        Top := QSelectNum_Pos_Y.Value;
        AutoSize := True;
        If QRBDetail.Height < (Top + Height) Then
          QRBDetail.Height := (Top + Height);
      End;
    End;
  End;
end;

procedure TFRExecRel.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  inherited;
  Action := caFree;
  FRExecRel := Nil;
end;

end.
