unit URelatorio;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  UTCADSIMPLES, ImgList, Db, Menus, ComCtrls, StdCtrls, Mask, Buttons,
  ExtCtrls, DBCtrls, Grids, DBGrids;

type
  TFRelatorio = class(TFTCadSimples)
    Label1: TLabel;
    DBEdit1: TDBEdit;
    Label2: TLabel;
    DBEdit2: TDBEdit;
    Label3: TLabel;
    DBEdit3: TDBEdit;
    SBRelatorio: TSpeedButton;
    SBCriaRel: TSpeedButton;
    procedure FormActivate(Sender: TObject);
    procedure SBRelatorioClick(Sender: TObject);
    procedure SBCriaRelClick(Sender: TObject);
    procedure SBConsultaClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FRelatorio: TFRelatorio;

implementation

uses URelatorio_cl, UReporterWiz, URelatorioVar, UOracle_cl,
  URelatorioCons, URExecRel;

{$R *.DFM}

procedure TFRelatorio.FormActivate(Sender: TObject);
begin
  inherited;
  With DMRelatorio do
  Begin
    QRelatorio.SetVariable('PK',1);
    QRelatorio.Open;
  End;
end;

procedure TFRelatorio.SBRelatorioClick(Sender: TObject);
Var wOk : Boolean;
begin
  inherited;
  With DMRelatorio do
  Begin
    wOk := True;
    QWhere.Open;
    QWhere.First;
    If FRelatorioVar = Nil then
      FRelatorioVar := TFRelatorioVar.Create(Self);
    FRElatorioVar.MVar.Lines.Clear;
    While Not QWhere.Eof do
    Begin
      If DMRelatorio.QWhereCod_Relatorio.Value = DMRelatorio.QRelatorioCod_Relatorio.Value then
      Begin
        If FRelatorioVar.ShowModal <> mrOk then
          wOk := False;
        // Depois do ShowModal o Qwhere estara no EOF
      End;
    End;

    If wOk Then
    Begin
      DMRelatorio.GeraSQL(FRElatorioVar.MVar.Lines);
      If FRExecRel = Nil then
        FRExecRel := TFRExecRel.Create(Self);
      FRExecRel.PreparaCampos;
//      Memo1.Lines := QExecRel.SQL;
      FRExecRel.QRPrimario.Preview;
      FRExecRel.Release;
      FRExecRel := Nil;
    End;
  End;

end;

procedure TFRelatorio.SBCriaRelClick(Sender: TObject);
begin
  inherited;
  If FReporterWiz = Nil then
    FReporterWiz := TFReporterWiz.Create(Self);
  DMOracle.DBCemapa.StartTransaction;
  If FReporterWiz.ShowModal = mrOk Then
    DMOracle.DBCemapa.Commit
  Else
    DMOracle.DBCemapa.RollBack;

end;

procedure TFRelatorio.SBConsultaClick(Sender: TObject);
begin
  inherited;
  If FRelatorioCons = Nil then
    FRelatorioCons := TFRelatorioCons.Create(Self);
  If FRelatorioCons.ShowModal = mrOk then
  With DMRelatorio do
  Begin
    QRelatorio.Close;
    QRelatorio.SetVariable('PK',QRelatorioConsCod_Relatorio.Value);
    QRelatorio.Open;
  End;
end;

end.
